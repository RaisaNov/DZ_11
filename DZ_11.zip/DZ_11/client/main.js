const chatbox = document.getElementById('chatbox');
const messageInput = document.getElementById('messageInput');
const sendButton = document.getElementById('sendButton');

const ws = new WebSocket('ws://localhost:8080');

ws.onopen = () => {
  console.log('Connected to WebSocKet');
};

ws.onmessage = event => {
  const message = event.data;
  displayMessage(message);
};

ws.onclose = () => {
  console.log('Disconnected from WebSockey');
};

ws.onerror = error => {
  console.error('Websocket error:', error);
};

function displayMessage(message) {
  const newMessage = document.createElement('p');
  newMessage.textContent = message;
  chatbox.appendChild(newMessage);
  chatbox.scrollTop = chatbox.scrollHeight;
};

sendButton.addEventListener('click', sendMessage);
messageInput.addEventListener('keyup', event => {
  if (event.key === 'Enter') {
    sendMessage();
  }
});

function sendMessage() {
  const message = messageInput.value;
  if(message.trim() !== ""){
    ws.send(message);
    messageInput.value = '';
    displayMessage("Я:" + message);
  }
}


/* document.addEventListener('DOMContentLoaded', () => {
  const chatMessages = document.getElementById('chatMessages');
  const messageInput = document.getElementById('messageInput');
  const sendButton = document.getElementById('sendButton');
  const connectionStatus = document.getElementById('connectionStatus');
  
  const ws = new WebSocket('ws://localhost:8080'); */

  /* ws.onopen = () => {
      connectionStatus.textContent = 'Подключено';
      connectionStatus.style.color = '#4CAF50';
  };

  ws.onmessage = (event) => {
    const message = event.data;
    displayMessage(message);
          const data = JSON.parse(event.data); 
      const message = document.createElement('div'); 
      message.className = `message ${data.type === 'system' ? 'system-message' : ''}`; 
      message.textContent = data.type === 'system' ? `🔔 ${data.message}` : data.message; 
       chatMessages.appendChild(message);
      
      chatMessages.scrollTop = chatMessages.scrollHeight; 
  };

  function displayMessage(message) {
    const newMessage = document.createElement('p');
    newMessage.textContent = message;
    chatbox.appendChild(newMessage);
    chatbox.scrollTop = chatbox.scrollHeight;
  };

  ws.onclose = () => {
      connectionStatus.textContent = 'Соединение закрыто';
      connectionStatus.style.color = '#f44336';
      
      const message = document.createElement('div');
      message.className = 'message system-message';
      message.textContent = '🔔 Соединение с сервером прервано';
      chatMessages.appendChild(message);
  };

  ws.onerror = (error) => {
      connectionStatus.textContent = 'Ошибка соединения';
      connectionStatus.style.color = '#f44336';
      console.error('WebSocket error:', error);
  };

  const sendMessage = () => {
      const messageText = messageInput.value.trim();
      if (messageText && ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({
              type: 'message',
              message: messageText
          }));
          messageInput.value = '';
      }
  };

  sendButton.addEventListener('click', sendMessage);

  messageInput.addEventListener('keypress', (event) => {
      if (event.key === 'Enter') {
          sendMessage();
      }
  });
}); */ 

