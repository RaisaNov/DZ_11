const WebSocket = require ('ws');

const wss = new WebSocket.Server({port: 8080});

wss.on('connection', ws => {
  console.log('Client connected');

  ws.send('Welcome to the chat!');

  ws.on('massage', massage => {
    console.log('Resived:', massage);
    wss.clients.forEach(client => {
      if (client != ws && client.readyState === WebSocket.OPEN){
        client.send(massage);
      }
    })
  });

  ws.on('close', () => {
    console.log('Client closed');
  })

  ws.on('error', (error)=> {
    console.log('WebSocket error:', error);
  });
});

console.log('WebSocked server started on port 8080');


